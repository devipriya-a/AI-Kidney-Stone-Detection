import os
import cv2
import numpy as np
from skimage.measure import label, regionprops

# -----------------------------
# Paths
# -----------------------------
image_dir = r"C:\Users\karti\Downloads\Kindey Stone Dataset\Kindey Stone Dataset\Augmented\ctonecheck"  # Your test data directory
output_dir = os.path.join(image_dir, "segmented_results")  # Folder to save segmented images
os.makedirs(output_dir, exist_ok=True)  # Create output folder if it doesn't exist

# Function for kidney stone segmentation and identification
def segment_and_identify_stones(image_path, hu_threshold=150, min_area=20, max_area=500, center_exclusion_radius=150):
    """
    Segments and identifies kidney stones in a CT image using intensity thresholding.
    Labels detected stones as "kidney stone" on the image.
    Excludes potential false positives in the center (e.g., spinal cord or vertebra).
    
    Improvements:
    - Added max_area to exclude large regions like the spinal cord.
    - Increased center_exclusion_radius to better cover central areas.
    - Use Otsu's thresholding for adaptive threshold calculation.
    
    Parameters:
    - image_path: Path to the input CT image.
    - hu_threshold: Initial guess for threshold (used with Otsu).
    - min_area: Minimum pixel area to consider as a stone.
    - max_area: Maximum pixel area to consider as a stone (excludes large structures).
    - center_exclusion_radius: Radius around the image center to exclude regions (pixels).
    
    Returns:
    - stone_count: Number of detected stones.
    - output_path: Path to the saved segmented image.
    """
    # Load image in grayscale
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Image not found at {image_path}")
    
    height, width = img.shape
    center_y, center_x = height // 2, width // 2  # Image center
    print(f"Image size: {height} x {width}")
    
    # Normalize image
    img_normalized = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX)
    
    # Use Otsu's thresholding for adaptive threshold
    _, thresh = cv2.threshold(img_normalized, hu_threshold, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Morphological operations to clean noise
    kernel = np.ones((5, 5), np.uint8)  # Increased kernel size for better noise reduction
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    # Label connected components
    labeled = label(thresh)
    regions = regionprops(labeled)
    
    # Draw bounding boxes and labels on original image
    output = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    stone_count = 0
    for region in regions:
        if min_area <= region.area <= max_area:
            centroid_y, centroid_x = region.centroid  # Get centroid of the region
            
            # Exclude if centroid is within the central exclusion radius (likely spinal cord)
            dist_to_center = np.sqrt((centroid_y - center_y)**2 + (centroid_x - center_x)**2)
            if dist_to_center <= center_exclusion_radius:
                continue  # Skip central structures
            
            minr, minc, maxr, maxc = region.bbox
            cv2.rectangle(output, (minc, minr), (maxc, maxr), (0, 255, 0), 2)
            
            # Add label "kidney stone" above the bounding box
            cv2.putText(output, "kidney stone", (minc, minr - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
            
            stone_count += 1
    
    # Save segmented image
    output_path = os.path.join(output_dir, f"segmented_{os.path.basename(image_path)}")
    cv2.imwrite(output_path, output)
    
    return stone_count, output_path

# -----------------------------
# Process all images in the test directory
# -----------------------------
image_files = [f for f in os.listdir(image_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
if not image_files:
    print(f"❌ No image files found in {image_dir}. Check directory.")
else:
    print(f"✅ Found {len(image_files)} images in {image_dir}.")

# Initialize totals
total_stones = 0
stone_images = 0
normal_images = 0

for image_file in image_files:
    image_path = os.path.join(image_dir, image_file)
    print(f"\nProcessing: {image_file}")
    
    if not os.path.exists(image_path):
        print(f"❌ Image not found at {image_path}. Skipping.")
        continue

    try:
        stone_count, output_path = segment_and_identify_stones(
            image_path, 
            hu_threshold=150, 
            min_area=20, 
            max_area=500,  # Adjust based on typical stone size vs. spinal cord
            center_exclusion_radius=150  # Increased to better exclude central spinal cord
        )
        total_stones += stone_count
        
        if stone_count > 0:
            print(f"🪨 Identified {stone_count} kidney stone(s) (Stone image). Saved to: {output_path}")
            stone_images += 1
        else:
            print(f"✅ No kidney stones identified (Normal image). Saved to: {output_path}")
            normal_images += 1
    
    except Exception as e:
        print(f"❌ Error processing {image_file}: {e}. Skipping.")

# -----------------------------
# Display summary
# -----------------------------
print(f"\n✅ Processing completed.")
print(f"Total images with kidney stones: {stone_images}")
print(f"Total normal images: {normal_images}")
print(f"Total kidney stones detected across all images: {total_stones}")
print(f"Segmented images saved to: {output_dir}")