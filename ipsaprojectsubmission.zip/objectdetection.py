import os
import cv2
import numpy as np
import tensorflow as tf
from ultralytics import YOLO
from tensorflow.keras.models import load_model

# -----------------------------
# Configuration
# -----------------------------
IMG_SIZE = (224, 224)  # Match classification model's input size
CLASSIFIER_PATH = "updated_kidney_stone_classifier.keras"  # Trained classifier
YOLO_MODEL_PATH = "yolov8n.pt"  # Pre-trained YOLOv8 nano model
DATASET_PATH = r"D:\Data Science\Image processing project\IPSA\dataset1"
OUTPUT_DIR = os.path.join(DATASET_PATH, "output_detections")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Center exclusion parameters (adjust based on image dimensions)
CENTER_EXCLUSION_FRACTION = 0.2  # Fraction of image width/height for exclusion zone
EXCLUSION_RADIUS = None  # Set to None for rectangular exclusion, or a pixel value for circular

# -----------------------------
# Load Models
# -----------------------------
try:
    classifier = load_model(CLASSIFIER_PATH)
    detector = YOLO(YOLO_MODEL_PATH)
except Exception as e:
    print(f"Error loading models: {e}")
    exit(1)

# -----------------------------
# Process CT Scan Image (Classification + Detection)
# -----------------------------
def detect_kidney_stones(image_path, conf_threshold=0.3):
    try:
        # Load and preprocess CT scan image for classification
        img = cv2.imread(image_path)
        if img is None:
            print(f"Failed to load image: {image_path}")
            return

        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_resized = cv2.resize(img_rgb, IMG_SIZE)
        img_input = img_resized.astype("float32") / 255.0
        img_input = np.expand_dims(img_input, axis=0)

        # Step 1: Classify image for kidney stone presence
        pred = classifier.predict(img_input, verbose=0)[0][0]
        class_label = "Kidney Stone" if pred > 0.3 else "No Kidney Stone"
        class_conf = pred if pred > 0.3 else 1 - pred
        print(f"Classification: {class_label} (Confidence: {class_conf:.2f})")

        # Step 2: Detect kidney stones if classified as positive
        if pred > 0.3:
            results = detector(img, verbose=False)  # Run YOLOv8 detection
            img_height, img_width = img.shape[:2]
            center_x, center_y = img_width / 2, img_height / 2
            exclusion_width = img_width * CENTER_EXCLUSION_FRACTION
            exclusion_height = img_height * CENTER_EXCLUSION_FRACTION

            for result in results:
                boxes = result.boxes.xyxy.cpu().numpy()
                classes = result.boxes.cls.cpu().numpy()
                confidences = result.boxes.conf.cpu().numpy()

                for box, cls, conf in zip(boxes, classes, confidences):
                    if conf > conf_threshold:
                        x1, y1, x2, y2 = map(int, box)
                        # Calculate bounding box center
                        box_center_x = (x1 + x2) / 2
                        box_center_y = (y1 + y2) / 2

                        # Check if box center is in exclusion zone (rectangular or circular)
                        if EXCLUSION_RADIUS is None:
                            # Rectangular exclusion
                            if (center_x - exclusion_width <= box_center_x <= center_x + exclusion_width and
                                center_y - exclusion_height <= box_center_y <= center_y + exclusion_height):
                                continue  # Skip detections in central region (likely spinal cord)
                        else:
                            # Circular exclusion
                            distance = np.sqrt((box_center_x - center_x) ** 2 + (box_center_y - center_y) ** 2)
                            if distance <= EXCLUSION_RADIUS:
                                continue  # Skip detections in central region

                        # Label all non-central detections as "kidney stone"
                        label = "kidney stone"
                        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        cv2.putText(img, f"{label} {conf:.2f}", (x1, y1 - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        # Save result
        output_path = os.path.join(OUTPUT_DIR, os.path.basename(image_path))
        cv2.imwrite(output_path, img)
        print(f"Saved detection result to {output_path}")

    except Exception as e:
        print(f"Error processing {image_path}: {e}")

# -----------------------------
# Test on CT Scan Images from Test Set
# -----------------------------
if __name__ == "__main__":
    test_images_dir = os.path.join(DATASET_PATH, "test", "images")
    if not os.path.exists(test_images_dir):
        print(f"Test images directory not found: {test_images_dir}")
        exit(1)

    for filename in os.listdir(test_images_dir):
        if filename.lower().endswith((".jpg", ".jpeg", ".png")):
            image_path = os.path.join(test_images_dir, filename)
            print(f"Processing CT scan: {image_path}")
            detect_kidney_stones(image_path)